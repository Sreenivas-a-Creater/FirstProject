package com.learnSphere.services;

import com.learnSphere.entity.Lesson;

public interface StudentServices {
	Lesson getLesson(int lessonId);
	
	
}
